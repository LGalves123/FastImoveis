-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30/10/2023 às 17:28
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `alimentos`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `alimentos`
--

CREATE TABLE `alimentos` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(10,2) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `origem` varchar(50) DEFAULT NULL,
  `data_validade` date DEFAULT NULL,
  `calorias` int(11) DEFAULT NULL,
  `peso_gramas` decimal(10,2) DEFAULT NULL,
  `fabricante` varchar(100) DEFAULT NULL,
  `codigo_de_barras` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `alimentos`
--

INSERT INTO `alimentos` (`id`, `nome`, `descricao`, `preco`, `categoria`, `origem`, `data_validade`, `calorias`, `peso_gramas`, `fabricante`, `codigo_de_barras`) VALUES
(11, 'Maçã', 'Uma fruta deliciosa', 2.99, 'Frutas', 'Local', '2023-12-31', 52, 150.00, 'Fazenda da Maçã', '123456789012'),
(12, 'Arroz', 'Arroz branco de alta qualidade', 3.49, 'Grãos', 'Nacional', '2024-10-15', 150, 1000.00, 'Marca do Arroz', '987654321098'),
(13, 'Frango', 'Peito de frango sem pele', 5.99, 'Carnes', 'Local', '2023-11-30', 165, 500.00, 'Frigorífico do Frango', '567890123456'),
(14, 'Leite', 'Leite integral fresco', 2.49, 'Laticínios', 'Local', '2023-11-15', 85, 1000.00, 'Laticínios do Bem', '654321098765'),
(15, 'Cenoura', 'Cenoura orgânica', 1.99, 'Vegetais', 'Local', '2023-11-30', 41, 200.00, 'Fazenda da Cenoura', '789012345678'),
(16, 'Salmão', 'Filé de salmão fresco', 29.99, 'Peixes', 'Importado', '2023-11-20', 195, 250.00, 'Mar Pescados', '210987654321'),
(17, 'Pão Integral', 'Pão integral caseiro', 2.49, 'Pães', 'Local', '2023-10-31', 80, 500.00, 'Padaria da Vila', '876543210987'),
(18, 'Iogurte', 'Iogurte natural', 1.79, 'Laticínios', 'Local', '2023-12-15', 120, 200.00, 'Laticínios Saboroso', '345678901234'),
(21, 'Chocolate Amargo', 'Pó de chocolate/Mistura para bolo', 2.99, 'Doces e sobremesas', 'Local', '2023-10-28', 200, 500.00, 'Garoto', '301135037676');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`) VALUES
(1, 'adriel', 'softgamebr4@gmail.com', '1234'),
(2, 'Alex', 'azulRaptor27@gmail.com', '1234');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `alimentos`
--
ALTER TABLE `alimentos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `alimentos`
--
ALTER TABLE `alimentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
